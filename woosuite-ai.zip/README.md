WoosuiteAI is a Plugin for woprdpress.
Its objective is to serve the basics in:
Using the user Gemini API Key to run all the available functions of the plugin automatically with AI suggestions
Security, all the necessary one, Antivirus, Spam, Anti-Pishing, caPTCHA, etc...
Backup on cloud (Consigurable by the user) Automatic on schedule or manual, option to only delete manually a backup or automatically after a max number of backup set by user
AI SEO, Automatically update the whole website, products, images on the site to have a 100% SEO ready site and 100% reachable and readable by any LLM AI tool.
Email marketing to fetch all data from client only and resgistered clients. Fetch abandonned cart, Auto send email when order is made to thank client, Autosend email when update on delivery, Prepare marketing campaigns, All these emails must be generated with AI suggestions and there is an option to create any type of email.
A setting page that allows the clients to setup all necessary options as well as intruducing the API key for Gemini all in an extremely secure way
The plugin will be adding other options in future updates.
The objective of this plugin is to be userfriendly, easy to use, necessary options and as light as possible to run as fast as possible.
